from __future__ import annotations


class PoetryCoreException(Exception):
    pass
