from __future__ import annotations

from poetry.core.constraints.version import EmptyConstraint


__all__ = ("EmptyConstraint",)
