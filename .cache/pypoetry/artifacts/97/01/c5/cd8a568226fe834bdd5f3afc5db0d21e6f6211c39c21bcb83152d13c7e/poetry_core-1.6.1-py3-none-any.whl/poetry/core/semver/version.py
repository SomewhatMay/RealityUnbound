from __future__ import annotations

from poetry.core.constraints.version import Version


__all__ = ("Version",)
